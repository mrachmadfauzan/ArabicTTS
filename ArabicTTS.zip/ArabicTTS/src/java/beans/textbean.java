/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author Papah
 */
public class textbean {
    private String nama = new String();
    
    public String getNama(){
        return nama;
    }
            
    public void setNama(String name){
        this.nama = name;
    }
}
